# 10 question 4 option quiz
#by APG

from quizAPGData import *

#custom function
def run_quest(quest,check,ansU,ansR):
    while check == False:
        print (quest)
        try:
                ansU = int(input("Your answer >"))
                if ansU == ansR:
                        score += 1
                        check = True
                elif 0 < ansU < 5:
                        check = True
                else:
                        print("Please only type positve whole integers from 1-4")
        except ValueError:
                print("you didnt't enter one of the numbers given, please try again")

               
